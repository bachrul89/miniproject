<?php 
error_reporting(0);
$koneksi = mysqli_connect("localhost","root","","dblist_dts_pro");

// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}

?>