</div>
</div>

<script src="template/assets/dist/js/bootstrap.bundle.min.js"></script>
<script src="template/dashboard.js"></script>
</body>

</html>