<?php include "header.php";?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
	<div
		class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
		<h1 class="h2"> Daftar Tugas </h1>
	</div>

	<?php 
	if (!empty($_SESSION['ok_cek'])) {
		echo $_SESSION['ok_cek'];
	}
	?>
	<div style="padding-bottom:20px">
		<a class="btn btn-primary btn-sm" href="input_tugas.php" role="button"> Tambah Data </a>

		<a class="btn btn-info btn-sm" href="" role="button"> Refresh </a>
	</div>

	<table class="table table-hover table-responsive">
		<tr>
			<th> No. </th>
			<th> Nama Tugas </th>
			<th> User </th>
			<th> Mulai Tugas </th>
			<th> Akhir Tugas </th>
			<th> Aksi </th>
		</tr>
		<?php 
		include 'koneksi.php';
		$no = 1;
		$data = mysqli_query($koneksi,"select * from tbl_data_task");
		while($d = mysqli_fetch_array($data)){
			?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $d['nm_tugas']; ?></td>
			<td><?php echo $d['user_tugas']; ?></td>
			<td><?php echo $d['tgl_mulai']; ?></td>
			<td><?php echo $d['tgl_selesai']; ?></td>

			<td>
				<a class="btn btn-success btn-sm" href="edit_tugas.php?id=<?php echo $d['id']; ?>"> Edit </a>
				<a class="btn btn-danger btn-sm" href="hapus_tugas.php?id=<?php echo $d['id']; ?>"> Hapus </a>
			</td>
		</tr>
		<?php 
		}
		?>

	</table>

</main>
<?php include "footer.php";
unset($_SESSION['error_cek']);
unset($_SESSION['ok_cek']);

?>