<?php 
session_start();

// koneksi database
include 'koneksi.php';

$id = $_GET['id'];

// menghapus data dari database
$hasil = mysqli_query($koneksi,"delete from tbl_data_task WHERE id='$id'");

if ($hasil) {
	$_SESSION['ok_cek'] = '<div class="alert alert-warning" role="alert"> Data Berhasil Dihapus! </div>';
	echo '<script >
	setTimeout(function () {
		window.location = "data_tugas.php";
	}, 0); </script>';
}

?>