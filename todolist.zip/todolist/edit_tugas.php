<?php
include "header.php";
include "koneksi.php";

if ($_POST) {
$error = array();
$ok = array();

$id_tugas = $_POST['id_tugas'];
$nm_tugas = $_POST['nm_tugas'];
$user_tugas = $_POST['user_tugas'];
$tgl_mulai = $_POST['tgl_mulai'];
$tgl_selesai = $_POST['tgl_selesai'];

if (empty($nm_tugas)) {
$error['nm_tugas'] = 'Nama Tugas Harus Diisi';
}

if(empty($error)) { // gak ada error

$sql = "UPDATE tbl_data_task SET

nm_tugas = '$nm_tugas',
user_tugas = '$user_tugas',
tgl_mulai = '$tgl_mulai',
tgl_selesai = '$tgl_selesai'

WHERE id = '" . $id_tugas . "'";
$hasil = mysqli_query($koneksi, $sql);

if ($hasil && empty($error)) {
$_SESSION['ok_cek'] = '<div class="alert alert-success" role="alert"> Data Berhasil Disimpan </div>';
echo '<script>
setTimeout(function() {
	window.location = "data_tugas.php";
}, 0);
</script>';
}


} // gak da eror

} // if POST


$id = $_GET['id'];
$data = mysqli_query($koneksi,"select * from tbl_data_task where id='$id'");
while($d = mysqli_fetch_array($data)){

?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
	<div
		class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
		<h1 class="h2"> Edit Data Tugas </h1>
	</div>

	<div class="card col-6">
		<div class="card-body">
			<form action="" method="POST">
				<div class="row">
					<div class="col-12">
						<div class="mb-3">
							<label for="nm_tugas" class="form-label"> Nama Tugas
								<span class="text-danger">
									<?php echo (isset($error['nm_tugas']) ? $error['nm_tugas'] : ''); ?></span>
							</label>
							<input type="hidden" name="id_tugas" id="id_tugas" value="<?php echo $d['id']; ?>">

							<input type="text" name="nm_tugas" id="nm_tugas" class="form-control"
								value="<?php echo $d['nm_tugas']; ?>" placeholder="Nama Tugas ... ">
						</div>
						<div class="mb-3">
							<label for="user_tugas" class="form-label"> Nama Anggota </label>
							<input type="text" name="user_tugas" id="user_tugas" class="form-control"
								value="<?php echo $d['user_tugas']; ?>" placeholder="Nama Anggota ...">
						</div>
						<div class="mb-3">
							<label for="tgl_mulai" class="form-label"> Tanggal Mulai </label>
							<input type="text" name="tgl_mulai" id="tgl_mulai" class="form-control"
								value="<?php echo $d['tgl_mulai']; ?>" placeholder="yyyy-mm-dd">
						</div>
						<div class="mb-3">
							<label for="tgl_selesai" class="form-label"> Tanggal Selesai </label>
							<input type="text" name="tgl_selesai" id="tgl_selesai" class="form-control"
								value="<?php echo $d['tgl_selesai']; ?>" placeholder="yyyy-mm-dd">
						</div>

						<div class="d-grid gap-2 d-md-flex justify-content-md-end">
							<button class="btn btn-success btn-sm" type="submit"> Simpan </button>
							<a class="btn btn-danger btn-sm" href="data_tugas.php"> Batal </a>

						</div>
					</div>
				</div>
			</form>
		</div>
	</div>


	<?php 
	}
	?>
</main>
<?php include "footer.php" ?>